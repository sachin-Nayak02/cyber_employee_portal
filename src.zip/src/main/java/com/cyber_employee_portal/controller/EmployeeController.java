package com.cyber_employee_portal.controller;

import com.cyber_employee_portal.dto.AdminUserRequest;

import com.cyber_employee_portal.dto.AdminUserResponse;
import com.cyber_employee_portal.dto.AnniversaryResponse;
import com.cyber_employee_portal.dto.BirthdayResponse;
import com.cyber_employee_portal.dto.RegisterRequest;
import com.cyber_employee_portal.dto.RegisterResponse;
import com.cyber_employee_portal.dto.UpdateEmployeeRequest;
import com.cyber_employee_portal.exception.EmailAlreadyExistsException;
import com.cyber_employee_portal.exception.EmployeeNotFoundException;
import com.cyber_employee_portal.service.EmployeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;


import java.util.List;
import org.springframework.http.ResponseEntity;
import java.util.*;

import org.springframework.http.ResponseEntity;
import com.cyber_employee_portal.dto.ForgotPasswordRequest;
import com.cyber_employee_portal.dto.HolidayDTO;
import com.cyber_employee_portal.dto.NetworkResponse;
import com.cyber_employee_portal.dto.ProjectResponse;
import com.cyber_employee_portal.dto.ResetPasswordRequest;


import org.springframework.web.bind.annotation.*;
import com.cyber_employee_portal.dto.CurrentDateTimeResponse;
import com.cyber_employee_portal.dto.EmployeeInfoResponse;
import com.cyber_employee_portal.dto.EmployeeLookupResponse;


@Tag(name = "Employee", description = "Employee registration and management endpoints")
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;

    @Operation(summary = "Register a new employee") 
    @PostMapping("/register")
    public ResponseEntity<RegisterResponse> register(@Valid @RequestBody RegisterRequest request) {
        RegisterResponse response = employeeService.register(request);
        return ResponseEntity.ok(response);
    }
    
    @Operation(summary = "Look up email by Employee ID (for registration autofill)")
    @GetMapping("/employee-lookup/{employeeId}")
    public ResponseEntity<EmployeeLookupResponse> lookupByEmployeeId(@PathVariable String employeeId) {
        return ResponseEntity.ok(employeeService.lookupByEmployeeId(employeeId)); 
    }
    
    @Operation(summary = "Register a new employee by Admin")
    @PostMapping("/admin/register")
    public ResponseEntity<AdminUserResponse> adminregister(@Valid @RequestBody AdminUserRequest request) {
    	AdminUserResponse response = employeeService.generateEmpId(request);
        return ResponseEntity.ok(response);
    }
    
    @Operation(summary = "Update an employee (only the fields you send get changed)")
    @PatchMapping("/update/{id}")
    public ResponseEntity<RegisterResponse> updateEmployee(@PathVariable Long id,
                                                            @Valid @RequestBody UpdateEmployeeRequest request) {
        RegisterResponse response = employeeService.updateEmployee(id, request);
        return ResponseEntity.ok(response);

    }
    
    @Operation(summary = "Request OTP for password reset")
    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, String>> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request) {
        String message = employeeService.forgotPassword(request);
        Map<String, String> response = new HashMap<>();
        response.put("message", message);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Reset password using OTP")
    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, String>> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        String message = employeeService.resetPassword(request);
        Map<String, String> response = new HashMap<>();
        response.put("message", message);
        return ResponseEntity.ok(response);

    }
 
    @Operation(summary = "Delete an employee by id")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }

    @ExceptionHandler(EmployeeNotFoundException.class)
    public ResponseEntity<String> handleNotFound(EmployeeNotFoundException e) {
        return ResponseEntity.status(404).body(e.getMessage());

    }

    @ExceptionHandler(EmailAlreadyExistsException.class)
    public ResponseEntity<String> handleEmailExists(EmailAlreadyExistsException e) {
        return ResponseEntity.status(400).body(e.getMessage());
    }
    @GetMapping("/birthdays/today")
    public ResponseEntity<List<BirthdayResponse>> getTodayBirthdays() {
        return ResponseEntity.ok(employeeService.getTodayBirthdays());
    }
    @GetMapping("/anniversaries/today")
    public ResponseEntity<List<AnniversaryResponse>> getTodayAnniversaries() {
        return ResponseEntity.ok(employeeService.getTodayAnniversaries());
    }
    @GetMapping("/birthdays/upcoming")
    public ResponseEntity<List<BirthdayResponse>> getUpcomingBirthdays() {

        return ResponseEntity.ok(employeeService.getUpcomingBirthdays()); 

    }
    @Operation(summary = "Get Today and Upcoming Birthdays")
    @GetMapping("/birthdays")
    public ResponseEntity<List<BirthdayResponse>> getBirthdayList() {

        return ResponseEntity.ok(employeeService.getBirthdayList());

    }
    @GetMapping("/gender/{gender}")
    public ResponseEntity<List<RegisterResponse>> getEmployeesByGender(
            @PathVariable String gender) {

        return ResponseEntity.ok(employeeService.getEmployeesByGender(gender));
    }
    @GetMapping("/currentDateTime")
    public ResponseEntity<CurrentDateTimeResponse> getCurrentDateTime() {
        return ResponseEntity.ok(employeeService.getCurrentDateTime());

    }

    public class DashboardResponse {
        private EmployeeInfoResponse employeeInfo;
        private ProjectResponse assignedProject;
        private List<NetworkResponse> teamMembers;
        private List<HolidayDTO> holidays;
        private List<BirthdayResponse> todayBirthdays;
        private List<BirthdayResponse> upcomingBirthdays;
        private List<AnniversaryResponse> todayAnniversaries;
        private List<AnniversaryResponse> upcomingAnniversaries;
    }
//    @ExceptionHandler(EmailAlreadyExistsException.class)
//    public ResponseEntity<String> handleEmailExists(EmailAlreadyExistsException e) {
//        return ResponseEntity.status(400).body(e.getMessage()); 
//    }
    
}